// TODO: Implement ExceptionHandlingMiddleware
// This file is part of the WasteCollectionPlatform.API project
