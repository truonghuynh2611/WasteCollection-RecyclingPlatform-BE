// TODO: Implement Program
// This file is part of the WasteCollectionPlatform.API project
