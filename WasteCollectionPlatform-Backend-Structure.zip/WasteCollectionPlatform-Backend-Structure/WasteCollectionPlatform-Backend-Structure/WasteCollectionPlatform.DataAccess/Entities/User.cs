// TODO: Implement User
// This file is part of the WasteCollectionPlatform.DataAccess project
