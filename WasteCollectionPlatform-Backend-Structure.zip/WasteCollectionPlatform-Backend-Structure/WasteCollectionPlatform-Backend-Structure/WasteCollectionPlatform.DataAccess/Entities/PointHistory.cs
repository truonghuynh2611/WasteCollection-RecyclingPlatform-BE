// TODO: Implement PointHistory
// This file is part of the WasteCollectionPlatform.DataAccess project
