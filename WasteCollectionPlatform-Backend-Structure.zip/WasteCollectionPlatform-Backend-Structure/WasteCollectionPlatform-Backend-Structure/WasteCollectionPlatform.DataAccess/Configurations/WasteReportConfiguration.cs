// TODO: Implement WasteReportConfiguration
// This file is part of the WasteCollectionPlatform.DataAccess project
