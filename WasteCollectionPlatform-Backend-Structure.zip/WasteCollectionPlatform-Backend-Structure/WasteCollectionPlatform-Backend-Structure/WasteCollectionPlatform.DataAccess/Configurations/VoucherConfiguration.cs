// TODO: Implement VoucherConfiguration
// This file is part of the WasteCollectionPlatform.DataAccess project
