// TODO: Implement CollectorConfiguration
// This file is part of the WasteCollectionPlatform.DataAccess project
