// TODO: Implement UserConfiguration
// This file is part of the WasteCollectionPlatform.DataAccess project
