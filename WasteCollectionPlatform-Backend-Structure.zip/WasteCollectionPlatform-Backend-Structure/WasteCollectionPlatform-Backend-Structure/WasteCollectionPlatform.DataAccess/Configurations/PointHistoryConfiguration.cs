// TODO: Implement PointHistoryConfiguration
// This file is part of the WasteCollectionPlatform.DataAccess project
