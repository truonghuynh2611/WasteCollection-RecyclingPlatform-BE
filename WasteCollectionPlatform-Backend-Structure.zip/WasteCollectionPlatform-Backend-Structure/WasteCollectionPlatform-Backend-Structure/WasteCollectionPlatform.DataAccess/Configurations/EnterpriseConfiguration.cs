// TODO: Implement EnterpriseConfiguration
// This file is part of the WasteCollectionPlatform.DataAccess project
