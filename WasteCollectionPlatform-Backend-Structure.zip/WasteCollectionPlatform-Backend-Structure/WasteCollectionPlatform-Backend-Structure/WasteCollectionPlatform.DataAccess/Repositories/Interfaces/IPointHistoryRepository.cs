// TODO: Implement IPointHistoryRepository
// This file is part of the WasteCollectionPlatform.DataAccess project
