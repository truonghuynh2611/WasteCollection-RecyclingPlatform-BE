// TODO: Implement IGenericRepository
// This file is part of the WasteCollectionPlatform.DataAccess project
