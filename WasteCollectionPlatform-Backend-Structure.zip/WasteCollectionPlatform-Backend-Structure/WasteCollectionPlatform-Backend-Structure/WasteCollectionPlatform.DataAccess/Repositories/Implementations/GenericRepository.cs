// TODO: Implement GenericRepository
// This file is part of the WasteCollectionPlatform.DataAccess project
