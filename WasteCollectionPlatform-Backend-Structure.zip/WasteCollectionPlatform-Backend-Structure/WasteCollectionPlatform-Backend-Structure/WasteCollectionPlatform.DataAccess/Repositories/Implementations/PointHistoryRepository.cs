// TODO: Implement PointHistoryRepository
// This file is part of the WasteCollectionPlatform.DataAccess project
