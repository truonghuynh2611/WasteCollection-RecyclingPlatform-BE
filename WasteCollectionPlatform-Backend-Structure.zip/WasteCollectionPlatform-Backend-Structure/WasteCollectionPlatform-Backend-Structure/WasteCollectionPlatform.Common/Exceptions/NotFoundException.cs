// TODO: Implement NotFoundException
// This file is part of the WasteCollectionPlatform.Common project
