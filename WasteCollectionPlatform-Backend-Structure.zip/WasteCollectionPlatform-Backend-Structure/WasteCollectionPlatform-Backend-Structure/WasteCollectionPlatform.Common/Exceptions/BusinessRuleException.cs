// TODO: Implement BusinessRuleException
// This file is part of the WasteCollectionPlatform.Common project
