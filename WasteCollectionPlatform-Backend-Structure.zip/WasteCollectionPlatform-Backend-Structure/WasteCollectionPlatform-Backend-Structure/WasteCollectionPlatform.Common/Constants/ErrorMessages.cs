// TODO: Implement ErrorMessages
// This file is part of the WasteCollectionPlatform.Common project
