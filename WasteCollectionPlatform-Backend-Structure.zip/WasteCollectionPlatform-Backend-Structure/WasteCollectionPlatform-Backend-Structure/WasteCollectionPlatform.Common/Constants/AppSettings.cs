// TODO: Implement AppSettings
// This file is part of the WasteCollectionPlatform.Common project
