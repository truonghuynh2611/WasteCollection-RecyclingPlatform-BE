// TODO: Implement JwtHelper
// This file is part of the WasteCollectionPlatform.Common project
