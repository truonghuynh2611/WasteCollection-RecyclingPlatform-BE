// TODO: Implement WasteType
// This file is part of the WasteCollectionPlatform.Common project
