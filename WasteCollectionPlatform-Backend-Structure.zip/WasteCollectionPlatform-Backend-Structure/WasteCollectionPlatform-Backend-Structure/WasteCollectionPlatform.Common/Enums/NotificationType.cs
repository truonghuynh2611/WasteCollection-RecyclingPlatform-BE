// TODO: Implement NotificationType
// This file is part of the WasteCollectionPlatform.Common project
