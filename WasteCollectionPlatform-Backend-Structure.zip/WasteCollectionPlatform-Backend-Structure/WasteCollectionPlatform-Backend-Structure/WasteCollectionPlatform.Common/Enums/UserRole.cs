// TODO: Implement UserRole
// This file is part of the WasteCollectionPlatform.Common project
