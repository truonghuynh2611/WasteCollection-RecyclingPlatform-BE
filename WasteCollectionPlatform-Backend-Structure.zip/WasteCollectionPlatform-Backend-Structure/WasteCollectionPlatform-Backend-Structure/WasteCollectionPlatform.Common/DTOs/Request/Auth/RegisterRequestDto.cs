// TODO: Implement RegisterRequestDto
// This file is part of the WasteCollectionPlatform.Common project
