// TODO: Implement LoginRequestDto
// This file is part of the WasteCollectionPlatform.Common project
