// TODO: Implement AuthResponseDto
// This file is part of the WasteCollectionPlatform.Common project
