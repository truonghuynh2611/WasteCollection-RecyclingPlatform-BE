// TODO: Implement ApiResponse
// This file is part of the WasteCollectionPlatform.Common project
